﻿<a name="_hlk128340178"></a>**LAPORAN PRAKTIKUM**

**DESAIN UI/UX**

![Description: Description: http://tmj.pnl.ac.id/wp-content/uploads/2019/08/TRKJ-1024x970.png](Aspose.Words.f8117e31-83bd-434c-bf6b-bd4fc6a9ec6e.001.png)

Oleh:

`	`Nama			: L Hafidl Alkhair

`	`Nim 			: 2023903430060

`	`Kelas			: TRKJ 2.C

`	`Jurusan 		: Teknologi Informasi dan Komputer

`	`Program Studi		: Teknologi Rekayasa Komputer Jaringan

`	`Dosen Pembimbing	: Muhammad Davi S.Kom.,M.Cs. 


![](Aspose.Words.f8117e31-83bd-434c-bf6b-bd4fc6a9ec6e.002.png)
\***








***KEMENTRIAN RISET, TEKNOLOGI DAN PERGURUAN TINGGI***

`	`***POLITEKNIK NEGERI LHOKSEUMAWE***

***TAHUN AJARAN 2024/2025***


**LEMBAR PENGESAHAN**

No Praktikum 			: 01/TIK/TRKJ 2C/ Dasar-dasar Desain UI/UX

Judul 		    		: Membuat Local Style

Nama 				: L Hafidl Alkhair

NIM 				: 2023903430060

Kelas 				: TRKJ 2.C

Jurusan 			: Teknologi Informasi dan Komputer (TIK)

Prodi 				: Teknologi Rekayasa Komputer Jaringan (TRKJ)

Tanggal Praktikum 		: 11 Desember 2024



<a name="_hlk98363215"></a>Dosen Pengampu 					Pengesahan

Praktikum 						Buket Rata,  18 Desember 2024



|L. Hafidl Alkhair|
| - |
|2023903430060|


|Muhammad Davi S.Kom.,M.Cs.|
| - |
|Nip. 198905102022031006|

2


